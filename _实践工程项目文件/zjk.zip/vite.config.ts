// vite.config.js
import { defineConfig } from "vite";
import vue from "@vitejs/plugin-vue";
import path from "path";

export default defineConfig({
  plugins: [vue() ],
  build: {
 
    lib: {
      entry: path.resolve(__dirname, "packages/index.ts"),
      name: "zjk",
      // fileName: "zjk",
      // formats: ["es"],
    },
    rollupOptions: {
      external: ["vue"],
      input:[path.resolve(__dirname, "packages/index.ts")],
      output: [{
        globals: {
          vue: "Vue",
        },
        format: "es",
        preserveModules: false,
        //打包后文件名
        entryFileNames: "[name].mjs",
        exports: "named",
        dir:'./dist'
      },
      // {
      //   //打包格式
      //   format: 'cjs',
      //   //打包后文件名
      //   entryFileNames: '[name].js',
      //   //让打包目录和我们目录对应
      //   preserveModules: true,
      //   exports: 'named',
      //   //配置打包根目录
      //   dir:'./dist/cjs'
      // }
    ],
    },
  },
  // resolve: {
  //   alias: {
  //     '@': path.resolve(__dirname, '/'),
  //   },
  // },
});
