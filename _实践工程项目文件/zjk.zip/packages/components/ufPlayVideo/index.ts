import { withInstall } from '../../../utils'

import ufPlayVideo from './ufPlayVideo.vue'

export const UfPlayVideo = withInstall(ufPlayVideo)

export default UfPlayVideo

export * from '.'