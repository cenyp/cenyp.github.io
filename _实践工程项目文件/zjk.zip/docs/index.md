---
# https://vitepress.dev/reference/default-theme-home-page
layout: home

hero:
  name: "优服文档"
  # text: "A VitePress Site"
  # tagline: My great project tagline
  actions:
    - theme: brand
      text: 简介
      link: /markdown-examples
    - theme: alt
      text: 组件文档
      link: /api-examples
    - theme: alt
      text: 方法/指令文档
      link: /api-examples

features:
  - title: 组件
    details: 包括封装的组件和组件库组件，都同步记录使用方法
  - title: 方法/指令
    details: 包括封装的工具方法、指令等等的使用
  - title: 开发注意事项
    details: 包括但不限于代码规范、开发注意事项、开发流程等等
---

