import { type App, type Component } from "vue";
export const withInstall = (comp: Component) => {
  (comp as Component & { install?: (app: App) => void }).install = (app: App) => {
    app.component(comp.name!, comp);
  };
  return comp;
};
