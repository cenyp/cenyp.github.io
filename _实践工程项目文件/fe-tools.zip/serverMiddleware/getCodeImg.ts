const fs = require("fs");
const bodyParser = require("body-parser");
const jsonParser = bodyParser.json();
export default function (req: any, res: any, next: any) {
  jsonParser(req, res, () => {
    const { type } = req.body;

    try {
      const imagePath = type === "dev" ? `./dev.png` : `./test.png`;
      const image = fs.readFileSync(imagePath);
      res.writeHead(200, {
        "Content-Type": "image/png",
        "Content-Length": image.length,
      });
      res.end(image);
    } catch (error) {
      console.error(error);
      res.statusCode = 500;
      res.end(
        JSON.stringify({
          code: -1,
          data: null,
          message: error,
        })
      );
    }
  });
}
