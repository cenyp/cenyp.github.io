const ci = require("miniprogram-ci");
const shell = require("shelljs");
const bodyParser = require("body-parser");
const jsonParser = bodyParser.json();

const {
  gitReset,
  gitFetch,
  gitCheckout,
  gitPull,
  gitCherryPick,
} = require("../utils/git.js");

const buildType = "build"; //dev
const scriptMap: { [key: string]: string } = {
  dev: `npm run ${buildType}:custom a-wx-dev --minimize `,
  test: `npm run ${buildType}:custom b-wx-test --minimize `,
};
let envType = "dev";
const PATH = "../cd-mini-program";

async function preview(fn: Function) {
  const project = new ci.Project({
    appid: "wx7baf4dfe739002b2",
    type: "miniProgram",
    projectPath: `${PATH}/dist/${buildType}/mp-weixin`,
    privateKeyPath: `../fe-tools/private.wx7baf4dfe739002b2.key`,
    ignores: [`node_modules/**/*`],
  });
  const previewResult = await ci.preview({
    project,
    setting: {
      minifyJS: true,
      minifyWXML: true,
      minifyWXSS: true,
      minify: true,
    },
    bigPackageSizeSupport: true, // 非官方文档用法
    qrcodeFormat: "image",
    qrcodeOutputDest: `./${envType}.png`,
    useCOS: true, // 非官方文档用法
    onProgressUpdate: (data: any) => {
      // console.log('onProgressUpdate',data);
    },
  });
  console.log("------------构建成功-----------\n", previewResult);
  fn();
}

function uniappBuild(fn: Function) {
  if (!scriptMap[envType]) {
    throw "参数错误";
  }
  shell.cd(PATH);
  shell.rm("-rf", "./dist/*");
  shell.rm("-rf", "test.png");
  shell.rm("-rf", "dev.png");
  // 异步，dev
  let hasFile = false;
  const key = setInterval(() => {
    // console.log(
    //   shell.test("-f", `./dist/${envType}/mp-weixin/app.json`),
    //   envType
    // );
    if (
      shell.test("-f", `./dist/${buildType}/mp-weixin/app.json`) &&
      !hasFile
    ) {
      hasFile = true;
      clearInterval(key);
      console.log("--------二维码构建---------------");
      preview(() => {
        fn(() =>
          setTimeout(() => {
            console.log("-----关闭进程------");
            shell.exit(0);
          }, 30 * 1000)
        );
      });
    }
  }, 500);
  shell.exec(
    scriptMap[envType],
    { windowsHide: true }
    // function (code, stdout, stderr) {
    //   console.log("Exit code:", code);
    //   console.log("Program output:", stdout);
    //   console.log("Program stderr:", stderr);
    // }
  );
  // 同步，build 要处理路径
  // const result = shell.exec(scriptMap[envType]);
  //  if (result.code !== 0) {
  //   throw '执行uniapp命令时出错'
  // } else {
  //   preview(fn);
  // }
}

function build(fn: Function) {
  uniappBuild(fn);
}

function gitOptimize(name: Function) {
  return new Promise(async (resolve, reject) => {
    // 丢弃本地修改
    try {
      await gitReset();
      await gitFetch();
      if (name) {
        await gitCheckout(name);
      }
      await gitPull();
      // 无需做处理
      // await gitCherryPick("origin/task-coding-106611-page-clear");
      resolve(0);
    } catch (error) {
      reject(error);
    }
  });
}
export default function (req: any, res: any, next: any) {
  res.setHeader("content-type", "application/json;charset=utf-8");
  jsonParser(req, res, async () => {
    const { type, name } = req.body;
    envType = type;
    try {
      await gitOptimize(name);
      console.log("-----构建开始-----");
      build((fn: Function) => {
        res.statusCode = 200;
        res.end(
          JSON.stringify({
            code: 200,
            data: null,
            message: "构建成功",
          })
        );
        // fn();
      });
    } catch (error) {
      console.error(error);
      res.statusCode = 500;
      res.end(
        JSON.stringify({
          code: -1,
          data: null,
          message: error,
        })
      );
    }
  });
}
