const { gitBranch, gitFetch } = require("../utils/git");

export default async function (req: any, res: any, next: any) {
  res.setHeader("content-type", "application/json;charset=utf-8");
  await gitFetch();
  gitBranch()
    .then((data: any[]) => {
      res.statusCode = 200;
      res.end(
        JSON.stringify({
          code: 200,
          data: data.map((e) => ({
            label: e.name,
            value: e.name,
            latestCommit: e.latestCommit,
          })),
          message: "",
        })
      );
    })
    .catch((error: any) => {
      res.statusCode = 500;
      res.end(
        JSON.stringify({
          code: -1,
          data: null,
          message: error,
        })
      );
    });
}
