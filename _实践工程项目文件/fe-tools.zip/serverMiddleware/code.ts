const fs = require("fs");
const path = require("path");
const PATH = "../cd-mini-program";

let filesPath: string[] = [];

function readFilesInDirectory(directoryPath: string) {
  const files = fs.readdirSync(directoryPath);
  files.forEach((file: string) => {
    const filePath = path.join(directoryPath, file);
    const stat = fs.statSync(filePath);
    if (stat.isDirectory()) {
      // 如果是目录，则递归遍历
      readFilesInDirectory(filePath);
    } else {
      filesPath.push(directoryPath + "/" + file);
    }
  });
}

function clearTtCode() {
  return new Promise((resolve, reject) => {
    try {
      filesPath = [];
      readFilesInDirectory(PATH + "/src");
      filesPath.forEach((file) => {
        const data = fs.readFileSync(file, "utf8");
        let clearData = data.replace(
          /\/\/ #(ifdef MP-TOUTIAO|ifdef H5|ifdef APP-NVUE|ifdef MP-ALIPAY|ifdef APP-PLUS-NVUE)[\s\S]*?#endif/g,
          ""
        );
        // clearData = clearData.replace(
        //   /<!-- #ifdef VUE2 -->[\s\S]*?<!-- #endif -->/g,
        //   ""
        // );

        // clearData = clearData.replace(
        //   /<!--\s*#ifdef VUE3\s*-->\s*(.*?)\s*<!--\s*#endif\s*-->/gs,
        //   "$1"
        // );
        // clearData = clearData.replace( /\/\/ #ifdef VUE3\s*(.*?)\s*\/\/ #endif/gs,  '$1')

        fs.writeFileSync(file, clearData);
      });
      console.log("-----------文件清理成功--------------");
      resolve(200);
    } catch (error) {
      console.error(error);
    }
  });
}
