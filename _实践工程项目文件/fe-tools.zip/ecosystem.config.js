module.exports = {
    apps: [
      {
        name: '小工具', // 替换成你的应用名称
        script: './node_modules/nuxt/bin/nuxt.js',
        args: 'start',
      }
    ]
  }
  