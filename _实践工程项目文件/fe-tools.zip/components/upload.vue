<template>
  <div style="margin: 30px">
    <p>请选择对应的桶，区分图片使用场景</p>
    <p>用这个上传的图片默认会替换掉域名</p>
    <a-upload v-model:file-list="fileList" :beforeUpload="beforeUpload" :multiple="true" v-if="!isUploaded">
      <a-button>
        <a-icon type="upload" />
        选择图片
      </a-button>
    </a-upload>

    <div style="margin-top: 20px">
      <div v-for="(item, index) in thumbUrlList" :key="item.name" class="flexLine">
        <img :height="100" :src="item.url" />
        <template v-if="!isUploaded">
          <a-input placeholder="请输入名称" v-model="item.name" />
          <a-icon type="delete" theme="twoTone" two-tone-color="#eb2f96" @click="delItem(index)" />
        </template>
        <template v-else>
          <span class="text">{{ item.url }}</span>
          <a-button type="link" @click="copyText(item.url)">复制</a-button>
        </template>
      </div>
    </div>

    <div style="margin: 20px 0">
      <a-radio-group :options="options" v-model="uploadType" />
    </div>

    <a-button type="primary" ghost style="margin-top: 30px" @click="againUpload" v-if="isUploaded">继续上传</a-button>
    <a-button type="primary" ghost style="margin-top: 30px" :loading="loading" @click="submit" v-else>上传</a-button>
  </div>
</template>

<script lang="ts">
import Vue from "vue";
import { uploadFile } from "../utils/upload";
import { copy, getPreviewUrl } from "../utils/index";
import { message } from "ant-design-vue";

export default Vue.extend({
  name: "upload",
  data() {
    const fileList: File[] = [];
    const thumbUrlList: {
      name: string;
      url: string;
    }[] = [];
    return {
      fileList: fileList,
      thumbUrlList: thumbUrlList,
      isUploaded: false,
      loading: false,

      //
      uploadType: "ufdj-erp-fe-1318198985",
      options: [
        { label: "后台erp", value: "ufdj-erp-fe-1318198985" },
        { label: "服务商", value: "fws-erp-fe-1318198985" },
        { label: "小程序", value: "cd-xd-mini-program-1318198985" },
        { label: "app/H5", value: "cd-app-1318198985" },
      ],
    };
  },
  methods: {
    async beforeUpload(file: File) {
      this.$data.fileList.splice(this.$data.fileList.length, 0, file);
      this.$data.thumbUrlList.splice(this.$data.thumbUrlList.length, 0, {
        name: file.name,
        url: await getPreviewUrl(file),
      });

      return false;
    },
    againUpload() {
      this.$data.fileList = [];
      this.$data.thumbUrlList = [];
      this.$data.isUploaded = false;
    },
    submit() {
      if (this.$data.fileList?.length === 0) {
        message.warning("请选择文件");
        return;
      }

      this.$data.loading = true;

      this.$data.fileList.forEach((file: File, index: number) => {
        uploadFile(
          this.$data.thumbUrlList[index].name,
          file,
          this.$data.uploadType
        ).then((url: string) => {
          this.$data.thumbUrlList[index].url = url;
        });
      });
      setTimeout(() => {
        this.$data.loading = false;
        this.$data.isUploaded = true;
      }, 500);
    },
    delItem(index: number) {
      this.$data.fileList.splice(index, 1);
      this.$data.thumbUrlList.splice(index, 1);
    },
    copyText(text: string) {
      copy(text);
    },
  },
});
</script>
<style>
.flexLine {
  display: flex;
  align-items: center;
  width: 500px;
  margin-top: 4px;
}

.text {
  width: 300px;
  overflow: hidden;
  /* 隐藏溢出部分 */
  text-overflow: ellipsis;
  /* 使用省略号表示溢出部分 */
  white-space: nowrap;
  /* 防止文本换行 */
  direction: rtl;
}

.ant-upload-list {
  display: none;
}
</style>
