<template>
  <div class="center">
    <div>
      <p>理论上只能使用test_2.0、release_2.0、master分支进行构建</p>
      <p>使用其余分支请和前端确认分支是否可用，且在git远端存在</p>
      <!-- <p>目前自动化构建限制在2M，随着后续迭代可能无法使用</p> -->
    </div>
    <div style="color: red" v-if="messageText">{{ messageText }}</div>
    <a-space>
      <a-tooltip>
        <template slot="title">
          构建分支选择：请选择正确分支，一般使用test2.0分支为最新代码分支
        </template>
        <a-select
          v-model:value="gitBranchVal"
          :options="branchList"
          placeholder="请选择分支"
          show-search
          allowClear
          :dropdownMatchSelectWidth="false"
          style="width: 200px"
        >
        </a-select>
      </a-tooltip>

      <a-tooltip>
        <template slot="title">
          构建环境变量选择：dev为开发环境，test为测试环境
        </template>
        <a-select
          v-model:value="envVal"
          style="width: 120px"
          placeholder="请选择环境"
        >
          <a-select-option value="dev">dev</a-select-option>
          <a-select-option value="test">test</a-select-option>
        </a-select>
      </a-tooltip>

      <a-tooltip>
        <template slot="title">
          构建按钮：点击进入构建状态，构建完毕自动显示二维码
        </template>
        <a-button
          type="primary"
          @click="runCommand"
          :loading="btnLoading"
          ref="buildBtn"
          >{{ btnLoading ? "构建中..." : "构建微信小程序" }}</a-button
        >
      </a-tooltip>
    </a-space>
    <div style="margin-top: 8px">
      最新提交记录：<br /><span style="color: #1890ff">{{ branchCommit }}</span>
    </div>

    <a-modal
      v-model:open="open"
      title="微信小程序二维码"
      :maskClosable="false"
      :footer="null"
    >
      <img :src="imgUrl" alt="" />
    </a-modal>
  </div>
</template>

<script lang="ts">
import { message } from "ant-design-vue";

export default {
  data: () => {
    const branchList: { label: string; value: string; latestCommit: string }[] =
      [];
    return {
      gitBranchVal: "test_2.0",
      branchList: branchList,
      envVal: "test",
      btnLoading: false,
      open: false,
      imgUrl: "",
      messageText: "",
    };
  },
  mounted() {
    this.$axios
      .post("/api/getGitBranch")
      .then(({ data }) => {
        this.$data.branchList = data.data;
      })
      .catch((error) => {
        console.error(error);
        message.error("获取分支失败");
        this.$data.messageText = "获取分支失败";
      });
  },
  computed: {
    branchCommit: function () {
      return (
        this.$data.branchList.find(
          (item) => item.value == this.$data.gitBranchVal
        )?.latestCommit || ""
      );
    },
  },
  methods: {
    async runCommand() {
      const type = this.$data.envVal;
      this.$data.btnLoading = true;
      this.$data.messageText = "";
      const response = (await this.$axios
        .post(
          "/api/buildFile",
          {
            type,
            name: this.$data.gitBranchVal,
          },
          { timeout: 600000 }
        )
        .catch((error) => {
          console.error(error);
          message.error("构建失败");
          this.$data.messageText = "构建失败";
          this.$data.btnLoading = false;
        })) as any;

      if (response.status === 200) {
        message.success("构建成功");
        this.getImg(type);
      } else {
        console.error(response);
        message.error("构建失败");
        this.$data.messageText = "构建失败";
      }
      this.$data.btnLoading = false;
    },
    async getImg(val: string) {
      const res = (await this.$axios
        .post(
          "/api/getCodeImg",
          {
            type: val,
          },
          {
            responseType: "blob",
          }
        )
        .catch((error) => {
          console.error(error);
          message.error("获取图片失败");
          this.$data.messageText = "获取图片失败";
        })) as any;

      if (res.status === 200) {
        this.$data.imgUrl = URL.createObjectURL(
          new Blob([res.data], { type: "image/png" })
        );
        this.$data.open = true;
      } else {
        console.error(res);
        message.error("获取图片失败");
        this.$data.messageText = "获取图片失败";
      }
    },
  },
};
</script>
<style scoped>
.center {
  /* position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%); */
  width: 500px;
  margin: 30px;
}
</style>
