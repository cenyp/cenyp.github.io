<template>
  <div>
    <a-tabs v-model:activeKey="activeKey" centered type="card">
      <a-tab-pane key="upload" tab="图片上传">
        <upload />
      </a-tab-pane>
      <a-tab-pane key="buildCode" tab="微信小程序构建">
        <buildCode
      /></a-tab-pane>
    </a-tabs>
  </div>
</template>

<script lang="ts">
import Vue from "vue";

export default Vue.extend({
  name: "IndexPage",
  data() {
    return {
      activeKey: "upload",
    };
  },
  methods: {},
});
</script>
