import simpleGit from "simple-git";
const projectPath = "../cd-mini-program";

export function gitFetch() {
  return new Promise((resolve, reject) => {
    try {
      const git = simpleGit(projectPath);
      git.fetch((err: any) => {
        if (err) {
          console.error(err);
          reject(err);
          return;
        }
        console.log("------更新分支成功-----");
        resolve("200");
      });
    } catch (error) {
      reject(error);
    }
  });
}

export function gitLatestLog(branch: string) {
  return new Promise((resolve, reject) => {
    try {
      const git = simpleGit(projectPath);
      git.log([branch, "-n", "1", "--pretty=format:%s"], (err, log: any) => {
        if (err) {
          console.error(err);
          reject(err);
          return;
        }
        resolve({
          name: branch.replace("remotes/origin/", ""),
          latestCommit: log.latest.hash,
        });
      });
    } catch (error) {
      reject(error);
    }
  });
}

export function gitBranch() {
  return new Promise<any[]>((resolve, reject) => {
    try {
      const git = simpleGit(projectPath);
      git.branch((async (err: any, branchSummary: any) => {
        if (err) {
          console.error(err);
          reject(err);
          return;
        }
        const branches = branchSummary.all.filter((e: any) =>
          e.startsWith("remotes/origin/")
        );
        Promise.all(
          branches.map((branch: string) => gitLatestLog(branch))
        ).then((result) => {
          console.log("------获取分支成功-----");
          resolve(result);
        });
      }) as any);
    } catch (error) {
      reject(error);
    }
  });
}

export function gitReset() {
  return new Promise((resolve, reject) => {
    try {
      const git = simpleGit(projectPath);
      git.reset(["--hard", "HEAD~"], (err) => {
        if (err) {
          console.error(err);
          reject(err);
          return;
        }
        console.log("------本地修改已丢弃-----");
        resolve("200");
      });
    } catch (error) {
      reject(error);
    }
  });
}

export function gitCheckout(name: string) {
  return new Promise((resolve, reject) => {
    try {
      const git = simpleGit(projectPath);
      git.checkout(name, (err) => {
        if (err) {
          console.error(err);
          reject(err);
          return;
        }
        console.log("------切换分支成功-----");
        resolve("200");
      });
    } catch (error) {
      reject(error);
    }
  });
}

export function gitPull() {
  return new Promise((resolve, reject) => {
    try {
      const git = simpleGit(projectPath);
      git.pull((err) => {
        if (err) {
          console.error(err);
          reject(err);
          return;
        }
        console.log("------分支更新成功-----");
        resolve("200");
      });
    } catch (error) {
      reject(error);
    }
  });
}

export function gitCherryPick(remoteBranch: string) {
  return new Promise((resolve, reject) => {
    try {
      const git = simpleGit(projectPath);
      git.merge([remoteBranch], (err, update) => {
        if (err) {
          console.error(err);
          reject(err);
          return;
        }
        if (update && update.summary.changes) {
          console.log("-----合并分支成功-------");
          resolve("200");
        } else {
          console.log("-----没有改动-------");
          resolve("200");
        }
      });
    } catch (error) {
      reject(error);
    }
  });
}
