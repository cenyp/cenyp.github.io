import COS from "cos-js-sdk-v5";
import { message } from "ant-design-vue";

const cosClient = new COS({
  SecretId: "AKIDbHrNrKfnlifT4Wr8KYdr36xax4CBvQgi",
  SecretKey: "rTp0xgBfw3xd8TbXJrAF7HI8mBLUbX6Y",
});

function getUUId() {
  let len = 32; //32长度
  let radix = 16; //16进制
  let chars =
    "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz".split("");
  let uuid = [],
    i;
  radix = radix || chars.length;
  if (len) {
    for (i = 0; i < len; i++) {
      uuid[i] = chars[0 | (Math.random() * radix)];
    }
  } else {
    let r;
    uuid[8] = uuid[13] = uuid[18] = uuid[23] = "-";
    uuid[14] = "4";
    for (i = 0; i < 36; i++) {
      if (!uuid[i]) {
        r = 0 | (Math.random() * 16);
        uuid[i] = chars[i === 19 ? (r & 0x3) | 0x8 : r];
      }
    }
  }
  return uuid.join("");
}

function add0(m: number) {
  return m < 10 ? "0" + m : m;
}

function getTime() {
  let time = new Date();
  let y = time.getFullYear();
  let m = time.getMonth() + 1;
  let d = time.getDate();
  return "" + y + add0(m) + add0(d);
}

function replaceUrl(
  url: string,
  uploadType:
    | "ufdj-erp-fe-1318198985"
    | "fws-erp-fe-1318198985"
    | "cd-xd-mini-program-1318198985"
    | "cd-app-1318198985"
    | "cd-website-1318198985"
) {
  if (uploadType === "ufdj-erp-fe-1318198985") {
    return url.replace(
      "ufdj-erp-fe-1318198985.cos.ap-guangzhou.myqcloud.com",
      "cdnerpfe.yfdjfw.com"
    );
  } else if (uploadType === "fws-erp-fe-1318198985") {
    return url.replace(
      "fws-erp-fe-1318198985.cos.ap-guangzhou.myqcloud.com",
      "cdnfws.yfdjfw.com"
    );
  } else if (uploadType === "cd-xd-mini-program-1318198985") {
    return url.replace(
      "cd-xd-mini-program-1318198985.cos.ap-guangzhou.myqcloud.com",
      "cdnmini.yfdjfw.com"
    );
  } else if (uploadType === "cd-app-1318198985") {
    return url.replace(
      "cd-app-1318198985.cos.ap-guangzhou.myqcloud.com",
      "cdnimage.yfdjfw.com"
    );
  }
}

export const uploadFile = (
  fileName: string,
  file: any,
  uploadType:
    | "ufdj-erp-fe-1318198985"
    | "fws-erp-fe-1318198985"
    | "cd-xd-mini-program-1318198985"
    | "cd-app-1318198985"
    | "cd-website-1318198985"
): Promise<string> => {
  return new Promise(async (resolve, reject) => {
    try {
      const data = await cosClient.uploadFile({
        Bucket: uploadType /* 填写自己的 bucket，必须字段 */,
        Region: "ap-guangzhou" /* 存储桶所在地域，必须字段 */,
        Key: `custom/${getTime()}/${getUUId()}/${fileName}` /* 存储在桶里的对象键（例如1.jpg，a/b/test.txt），必须字段 */,
        Body: file, // 上传文件对象
        SliceSize: 1024 * 1024 * 5,
      });
      let url = "https://" + replaceUrl(data.Location, uploadType);
      resolve(url);
    } catch (error) {
      console.error(error);

      message.warning("上传文件异常,请稍后再试!");
      reject("error");
    }
  });
};
