import { message } from "ant-design-vue";

/**复制到剪贴板 */
export function copy(url?: string) {
  if (!url) {
    message.warning("没有可复制内容");
    return;
  }

  const input = document.createElement("input");
  document.body.appendChild(input);
  input.setAttribute("value", url);
  input.select();
  if (document.execCommand("copy")) {
    document.execCommand("copy");
  }
  document.body.removeChild(input);

  message.success("复制成功");
}

/**生成图片预览链接 */
export function getPreviewUrl(file: File) {
  return new Promise<string>((resolve, reject) => {
    if (file) {
      const reader = new FileReader(); // 创建一个 FileReader 对象
      reader.onload = function (e) {
        return resolve(e.target?.result as any);
      };
      reader.readAsDataURL(file); // 以 DataURL 格式读取文件
    }
  });
}
