import { withInstall } from '../../../utils'

import ufButton from './ufButton.vue'

export const UfButton = withInstall(ufButton)

export default UfButton

export * from '.'