<template>
    <div>
        <button style="border: 1px solid royalblue;width: 100px;height: 60px;" @click="aa">111</button>
    </div>
</template>

<script lang="ts" setup>
 function aa( e) {
    console.log(11);
    
 }
</script>

 
