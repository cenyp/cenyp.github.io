<template>
    <div class="wrap">
        <a-modal v-model:visible="show" title="视频播放" :footer="null" @cancel="handleCancle" :width="650">
            <video class="wrap-video" width="600" :src="videoSrc" controls ref="videoRef">
            </video>
        </a-modal>
    </div>
</template>

<script lang="ts" setup>
// =======  依赖引入  =======
import { ref, watch } from "vue";
 
// =======  类型声明  =======

// =======  变量声明  =======
const show = ref<boolean>(false)
const videoSrc = ref<string>('')
const videoRef = ref()

// =======  主流程  =======
watch(
    () => show.value,
    () => {
        if (show.value === false) {
            videoRef.value?.pause()
            videoSrc.value = ''
        }
    }
)
// =======  函数声明  =======
function open(url: string) {
    videoSrc.value = url
    show.value = true
    setTimeout(() => {
        videoRef.value?.play()
    }, 200)
}

function handleCancle() {
    videoSrc.value = ''
    show.value = false
}

// =======  属性返回  =======
defineExpose({
    open,
})
</script>
<style lang="scss" scoped>
.wrap {
    width: 650px;
    &-video {
        max-height: 600px;
    }
}
</style>
