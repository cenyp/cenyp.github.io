22

<!-- Check out the documentation for the [full list of runtime APIs](https://vitepress.dev/reference/runtime-api#usedata). -->
<a-button type="primary" @click="show">视频预览</a-button>
<ufPlayVideo ref="lbPlayVideoRef" />

<script setup>
import { ref } from 'vue'

const lbPlayVideoRef = ref()
function show() {
    lbPlayVideoRef.value?.open('https://www.runoob.com/try/demo_source/movie.mp4')
}
</script>
