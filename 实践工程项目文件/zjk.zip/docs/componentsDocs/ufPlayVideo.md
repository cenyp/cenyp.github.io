# ufPlayVideo 视频预览组件

视频预览组件。

## 示例用法
<a-button type="primary" @click="show">视频预览</a-button>
<ufPlayVideo ref="lbPlayVideoRef" />
<script setup>
import { ref } from 'vue'

const lbPlayVideoRef = ref()
function show() {
    lbPlayVideoRef.value?.open('https://www.runoob.com/try/demo_source/movie.mp4')
}
</script>

```vue
<template>
    <a-button type="primary" @click="show">视频预览</a-button>
    <ufPlayVideo ref="lbPlayVideoRef" />
</template>
<script setup>
import { ref } from 'vue'

const lbPlayVideoRef = ref()

lbPlayVideoRef.value?.open(url)
</script>
```

<!-- ## 属性说明
| 属性                     | 说明                                                     | 类型          | 可选值    | 默认值        | 版本           |
| ------------------------ | -------------------------------------------------------- | ------------- | --------- | ------------- | ------------- | -->

## 方法说明
| 方法名 | 说明 | 参数  | 版本 |
| --- | --- | --- | --- |
| open | 预览视频链接 | (url: string) => void | |
