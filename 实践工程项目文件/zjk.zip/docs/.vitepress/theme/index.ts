import 'ant-design-vue/dist/antd.css';

import type { Theme } from "vitepress";
import DefaultTheme from "vitepress/theme";
import components from './components'
import Antd from 'ant-design-vue'

export default {
  extends: DefaultTheme,
  enhanceApp({ app }) {
    // 注册自定义全局组件
    Object.entries(components).forEach(([name, component]) => {
      app.component(name, component);
    })
    app.use(Antd)
  },
} satisfies Theme;
