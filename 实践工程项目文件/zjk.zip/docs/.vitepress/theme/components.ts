import UfButton from "../../../packages/components/ufButton";
import ufPlayVideo from "../../../packages/components/ufPlayVideo";

export default { UfButton ,ufPlayVideo};