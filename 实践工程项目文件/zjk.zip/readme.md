# 背景

1. 目前 web 项目，erp 和 服务商之间有许多组件和方法是共通的，每次修改要同时修改两个地方，增加开发成本。
2. 对于一些封装的组件/业务组件/方法/指令等等，是没有使用文档的，使用时需要查看源码，增加使用成本。
3. 目前项目组件抽离是不足的，业务组件太少。后续可以以此为基础，补充组件、方法等等
4. 对于一些项目的记录也可以放这块来

# 项目搭建技术

- vitepress 组件库文档
- vite 打包工具
- ant-design-vue 依赖 UI

## 安装依赖

```npm
npm init -y
npm add -D vitepress
npm i vite@latest -d
...
```

## 目录结构

安装完成后目录结构为

- dist 组件库构建产物
- docs 文档目录
  - .vitepress vitepress 配置文件
    - dist 文档构建产物
    - theme
      - index.ts 主题配置文件
    - config.mts 文档配置文件
  - index.md 文档首页
- packages
  - components 组件目录
- vite.config.ts

## 各配置文件

### /docs/.vitepress/theme/index.ts

```ts
// 引入依赖组件库样式，要在 vitepress 样式之前，避免覆盖
import "ant-design-vue/dist/antd.css";
import type { Theme } from "vitepress";
import DefaultTheme from "vitepress/theme";
/**
 * 引入组件库组件，文件格式如下
 * import xxx from "../../../packages/components/xxx";
 * export default { xxx };
 */
import components from "./components";
import Antd from "ant-design-vue";

export default {
  extends: DefaultTheme,
  enhanceApp({ app }) {
    // 注册自定义全局组件
    Object.entries(components).forEach(([name, component]) => {
      app.component(name, component);
    });
    app.use(Antd); // 注册依赖组件库，否则文档会无法解析依赖的组件
  },
} satisfies Theme;
```

### /docs/.vitepress/theme/config.mts

```ts
import { defineConfig } from "vitepress";

export default defineConfig({
  title: "xxx文档",
  description: "A VitePress Site",
  lang: "zh-CN",
  themeConfig: {
    nav: [
      { text: "首页", link: "/" },
      { text: "组件", link: "/componentsDocs/index" },
    ],

    sidebar: {
      // 动态生成侧边栏
      "/componentsDocs/": [
        {
          text: "组件",
          items: [{ text: "xxxx", link: "/componentsDocs/xxx" }],
        },
      ],
    },
    socialLinks: [
      { icon: "github", link: "https://github.com/vuejs/vitepress" },
    ],
  },
});
```

### 组件书写格式

- packages
  - components
    - xxx
      - xxx.vue // 组件
      - index.ts // 注册
  - index.ts // 主要是引入然后导出 export \* from './xxx'

#### 注册方法

```ts
// /packages/components/xxx/index.ts
import { withInstall } from "../../../utils";
import xxx from "./xxx.vue";
export const Xxx = withInstall(xxx);
export default Xxx;
export * from ".";

// utils/index.ts
export const withInstall = (comp) => {
  comp.install = (app) => {
    app.component(comp.name, comp);
  };
  return comp;
};
```

### vite.config.ts 配置文件
```ts
// vite.config.js
import { defineConfig } from "vite";
import vue from '@vitejs/plugin-vue'
import path from 'path'

export default defineConfig({
  plugins: [vue()],
  build: {
    lib: {
      entry: path.resolve(__dirname, "packages/components/index.ts"),
      name: "MyLib",
      fileName: "my-lib",
      formats: ['es']
    },
    rollupOptions: {
      external: ["vue"],
      output: {
        globals: {
          vue: "Vue",
        },
      },
    },
  },
});
```

### /docs/.vitepress/componentsDocs/xxx.md

对于组件，vitepress 支持直接书写，在全局注册（如上）/局部引入注册即可；
template 标签是不支持的，组件直接书写即可

````md
# ufPlayVideo 视频预览组件

视频预览组件。

## 示例用法

<a-button type="primary" @click="show">视频预览</a-button>
<playVideo ref="playVideo" />

<script setup>
import { ref } from 'vue'

const playVideo = ref()
function show() {
    playVideo.value?.open('xxx')
}
</script>

```vue
<template>
  <a-button type="primary" @click="show">视频预览</a-button>
  <playVideo ref="playVideo" />
</template>
<script setup>
import { ref } from "vue";

const playVideo = ref();

playVideo.value?.open(url);
</script>
```

## 方法说明

| 方法名 | 说明         | 参数                  | 版本 |
| ------ | ------------ | --------------------- | ---- |
| open   | 预览视频链接 | (url: string) => void |      |

```

